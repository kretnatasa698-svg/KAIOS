package dev.usecomet.cometos

import android.content.Intent
import android.content.pm.PackageManager
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LauncherIntentTest {
    @Test
    fun cometOsIsRegisteredAsHomeCandidate() {
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val candidates = ctx.packageManager.queryIntentActivities(home, PackageManager.MATCH_DEFAULT_ONLY)
        assertTrue(candidates.any { it.activityInfo.packageName == ctx.packageName })
    }
}
