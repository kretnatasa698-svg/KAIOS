package dev.usecomet.cometos.core.media

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationManagerCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Live media session data. Android only exposes other apps' sessions to apps that hold
 * notification-listener access, so the user must enable CometOS in
 * Settings > Notification access (see [CometNotificationListener]).
 */
@Singleton
class MediaRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val manager = context.getSystemService(MediaSessionManager::class.java)
    private val listenerComponent = ComponentName(context, CometNotificationListener::class.java)
    private val handler = Handler(Looper.getMainLooper())

    private val _state = MutableStateFlow(MediaUiState())
    val state: StateFlow<MediaUiState> = _state.asStateFlow()

    private var controller: MediaController? = null

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { onSessions(it) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() = refresh()
    }

    fun hasAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    /** Call on resume and when the listener service connects. */
    fun refresh() {
        if (!hasAccess()) {
            detach()
            _state.value = MediaUiState(hasAccess = false)
            return
        }
        try {
            manager.removeOnActiveSessionsChangedListener(sessionsListener)
            manager.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent, handler)
            onSessions(manager.getActiveSessions(listenerComponent))
        } catch (_: SecurityException) {
            detach()
            _state.value = MediaUiState(hasAccess = false)
        }
    }

    private fun onSessions(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(callback)
            controller = best
            best?.registerCallback(callback, handler)
        }
        publish()
    }

    private fun detach() {
        controller?.unregisterCallback(callback)
        controller = null
        runCatching { manager.removeOnActiveSessionsChangedListener(sessionsListener) }
    }

    private fun publish() {
        val c = controller
        if (c == null) {
            _state.value = MediaUiState(hasAccess = true)
            return
        }
        val md = c.metadata
        val ps = c.playbackState
        _state.value = MediaUiState(
            hasAccess = true,
            title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE),
            artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE),
            art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON),
            isPlaying = ps?.state == PlaybackState.STATE_PLAYING,
            durationMs = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L,
            positionMs = ps?.position ?: 0L,
            updatedAtElapsed = ps?.lastPositionUpdateTime ?: 0L,
            speed = ps?.playbackSpeed ?: 1f,
        )
    }

    fun togglePlayPause() {
        val controls = controller?.transportControls ?: return
        if (_state.value.isPlaying) controls.pause() else controls.play()
    }

    fun next() = controller?.transportControls?.skipToNext() ?: Unit
    fun previous() = controller?.transportControls?.skipToPrevious() ?: Unit
}
