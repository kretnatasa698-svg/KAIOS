package dev.usecomet.cometos.feature.home

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.usecomet.cometos.BuildConfig
import dev.usecomet.cometos.LauncherScreen
import dev.usecomet.cometos.LauncherUiState
import dev.usecomet.cometos.MainViewModel
import dev.usecomet.cometos.R
import dev.usecomet.cometos.core.glass.GlassBackdropProvider
import dev.usecomet.cometos.core.glass.depthBlur
import dev.usecomet.cometos.feature.lock.LockScreen

@Composable
fun LauncherRoot(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    // 0 = locked, 1 = unlocked. Shared by the lock layer and the Home layer.
    val unlock = remember { Animatable(if (state.isLocked) 0f else 1f) }
    LaunchedEffect(state.isLocked) { if (state.isLocked) unlock.snapTo(0f) }

    // A launcher must never finish on Back: consume it, pop to Home instead.
    BackHandler(enabled = true) { viewModel.onBack() }

    GlassBackdropProvider {
        HomeLayer(state, viewModel, unlock)
        if (state.isLocked) {
            LockScreen(progress = unlock, onUnlocked = viewModel::unlock)
        }
    }
}

/** Placeholder Home (replaced in Module 3). Blurs in/out with the unlock progress. */
@Composable
private fun HomeLayer(
    state: LauncherUiState,
    viewModel: MainViewModel,
    unlock: Animatable<Float, AnimationVector1D>,
) {
    val setDefault = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { viewModel.refreshDefaultStatus() }
    val blurMaxPx = with(LocalDensity.current) { 24.dp.toPx() }
    val locked = state.isLocked

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                if (locked) {
                    val s = 0.94f + 0.06f * unlock.value
                    scaleX = s
                    scaleY = s
                }
            }
            .depthBlur { if (locked) (1f - unlock.value) * blurMaxPx else 0f }
            .systemBarsPadding(),
        contentAlignment = Alignment.Center,
    ) {
        when (state.screen) {
            LauncherScreen.Home -> Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(stringResource(R.string.home_title), style = MaterialTheme.typography.displayMedium)
                Text(stringResource(R.string.home_subtitle), style = MaterialTheme.typography.bodyLarge)
                Text(
                    stringResource(R.string.version_label, BuildConfig.VERSION_NAME),
                    style = MaterialTheme.typography.labelMedium,
                )
                Spacer(Modifier.height(16.dp))
                if (state.isDefaultLauncher) {
                    val ok = stringResource(R.string.cd_status_active)
                    Text(
                        stringResource(R.string.default_launcher_active),
                        modifier = Modifier.semantics { contentDescription = ok },
                    )
                } else {
                    Button(onClick = { setDefault.launch(viewModel.createSetDefaultIntent()) }) {
                        Text(stringResource(R.string.set_default_launcher))
                    }
                }
            }
            LauncherScreen.AppLibrary, LauncherScreen.Settings -> Unit // Module 5
        }
    }
}
