package dev.usecomet.cometos.feature.lock

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.usecomet.cometos.R
import dev.usecomet.cometos.core.glass.BitmapBlur
import dev.usecomet.cometos.core.glass.GlassSurface
import dev.usecomet.cometos.core.media.MediaUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Compact pill when nothing plays (matches the mockup: "Music / Not playing"),
 * expands to a full card with blurred artwork, progress and controls for an active session.
 */
@Composable
fun MusicCard(
    state: MediaUiState,
    onOpenAccess: () -> Unit,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (state.hasTrack) {
        ActiveCard(state, onPrevious, onPlayPause, onNext, modifier)
    } else {
        IdlePill(state.hasAccess, onOpenAccess, modifier)
    }
}

@Composable
private fun IdlePill(hasAccess: Boolean, onOpenAccess: () -> Unit, modifier: Modifier) {
    GlassSurface(
        modifier = modifier.height(64.dp),
        shape = CircleShape,
        tintAlpha = 0.16f,
        onClick = if (hasAccess) null else onOpenAccess,
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(0.12f)),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.MusicNote, contentDescription = null) }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(stringResource(R.string.music_label), fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(
                    stringResource(if (hasAccess) R.string.music_not_playing else R.string.music_tap_to_allow),
                    fontSize = 13.sp, maxLines = 1, modifier = Modifier.alpha(0.7f),
                )
            }
        }
    }
}

@Composable
private fun ActiveCard(
    state: MediaUiState,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier,
) {
    val art = state.art
    val artImage = remember(art) { art?.asImageBitmap() }
    val blurredArt by produceState<ImageBitmap?>(null, art) {
        value = if (art == null) null else withContext(Dispatchers.Default) {
            runCatching { BitmapBlur.blur(art, scaleDown = 8, radius = 5, passes = 2).asImageBitmap() }.getOrNull()
        }
    }
    val fraction = rememberPlaybackFraction(state)

    GlassSurface(modifier = modifier, shape = RoundedCornerShape(30.dp), tintAlpha = 0.20f) {
        blurredArt?.let {
            Image(it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize().alpha(0.55f))
        }
        Column(Modifier.padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(0.14f)), Alignment.Center) {
                    if (artImage != null) {
                        Image(artImage, stringResource(R.string.cd_album_art), Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } else {
                        Icon(Icons.Rounded.MusicNote, contentDescription = null)
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(state.title.orEmpty(), fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(state.artist.orEmpty(), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.alpha(0.75f))
                }
            }
            Spacer(Modifier.height(10.dp))
            // Progress bar: the fraction is read while drawing, so ticking never recomposes the card.
            Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(Color.White.copy(0.22f)).drawBehind {
                drawRect(Color.White, size = Size(size.width * fraction.value, size.height))
            })
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onPrevious, Modifier.size(48.dp)) { Icon(Icons.Rounded.SkipPrevious, stringResource(R.string.cd_music_prev)) }
                IconButton(onPlayPause, Modifier.size(48.dp)) {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        stringResource(if (state.isPlaying) R.string.cd_music_pause else R.string.cd_music_play),
                        Modifier.size(30.dp),
                    )
                }
                IconButton(onNext, Modifier.size(48.dp)) { Icon(Icons.Rounded.SkipNext, stringResource(R.string.cd_music_next)) }
            }
        }
    }
}

@Composable
private fun rememberPlaybackFraction(state: MediaUiState): State<Float> =
    produceState(0f, state) {
        while (true) {
            value = if (state.durationMs > 0) (state.positionNow().toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f
            if (!state.isPlaying) break
            delay(500)
        }
    }
