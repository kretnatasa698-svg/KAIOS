package dev.usecomet.cometos.core.media

import android.service.notification.NotificationListenerService
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Intentionally empty listener: its only job is to grant MediaSessionManager access.
 * It never reads notification content.
 */
@AndroidEntryPoint
class CometNotificationListener : NotificationListenerService() {
    @Inject lateinit var media: MediaRepository

    override fun onListenerConnected() = media.refresh()
    override fun onListenerDisconnected() = media.refresh()
}
