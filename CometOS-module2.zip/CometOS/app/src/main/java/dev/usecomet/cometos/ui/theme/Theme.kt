package dev.usecomet.cometos.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CometAccent = Color(0xFF7AB8FF)

private val DarkColors = darkColorScheme(
    primary = CometAccent,
    onPrimary = Color(0xFF00213D),
    surface = Color(0xFF0B0F14),
    onSurface = Color(0xFFF2F5F8),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF1B6EC2),
    onPrimary = Color.White,
    surface = Color(0xFFF4F7FA),
    onSurface = Color(0xFF10151B),
)

@Composable
fun CometTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content,
    )
}
