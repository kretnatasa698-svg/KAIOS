package dev.usecomet.cometos.core.glass

import android.graphics.Bitmap
import kotlin.math.max

/**
 * CPU box blur used for the frosted backdrop. Works on every API level (26+),
 * so glass never depends on RenderEffect (API 31+). Always call off the main thread.
 * Heavy downscaling first makes it cheap: a 720px wallpaper blurs in a few ms.
 */
object BitmapBlur {

    fun blur(source: Bitmap, scaleDown: Int = 6, radius: Int = 7, passes: Int = 3): Bitmap {
        val w = max(1, source.width / scaleDown)
        val h = max(1, source.height / scaleDown)
        val small = Bitmap.createScaledBitmap(source, w, h, true)
        val a = IntArray(w * h)
        val b = IntArray(w * h)
        small.getPixels(a, 0, w, 0, 0, w, h)
        repeat(passes) {
            pass(a, b, w, h, radius, horizontal = true)
            pass(b, a, w, h, radius, horizontal = false)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        if (small !== source) small.recycle()
        return out
    }

    /** One sliding-window box blur pass with clamped edges. */
    private fun pass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val lines = if (horizontal) h else w
        val len = if (horizontal) w else h
        val stride = if (horizontal) 1 else w
        val div = 2 * r + 1
        for (line in 0 until lines) {
            val base = if (horizontal) line * w else line
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val p = src[base + i.coerceIn(0, len - 1) * stride]
                sr += (p shr 16) and 0xFF
                sg += (p shr 8) and 0xFF
                sb += p and 0xFF
            }
            for (i in 0 until len) {
                dst[base + i * stride] =
                    (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[base + (i + r + 1).coerceAtMost(len - 1) * stride]
                val rem = src[base + (i - r).coerceAtLeast(0) * stride]
                sr += ((add shr 16) and 0xFF) - ((rem shr 16) and 0xFF)
                sg += ((add shr 8) and 0xFF) - ((rem shr 8) and 0xFF)
                sb += (add and 0xFF) - (rem and 0xFF)
            }
        }
    }
}
