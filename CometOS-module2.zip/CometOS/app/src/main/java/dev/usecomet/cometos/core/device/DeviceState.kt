package dev.usecomet.cometos.core.device

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.text.format.DateFormat
import androidx.core.content.ContextCompat
import java.util.Date
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/** Live battery percentage from the sticky ACTION_BATTERY_CHANGED broadcast. */
fun batteryPercentFlow(context: Context): Flow<Int> = callbackFlow {
    fun read(i: Intent?) {
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (level >= 0 && scale > 0) trySend(level * 100 / scale)
    }
    val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = read(i)
    }
    val sticky = ContextCompat.registerReceiver(
        context, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED,
    )
    read(sticky)
    awaitClose { context.unregisterReceiver(receiver) }
}.distinctUntilChanged()

/** Time of the next alarm set in the Clock app, formatted for the user's locale, or null. */
fun nextAlarmLabel(context: Context): String? {
    val trigger = context.getSystemService(AlarmManager::class.java)?.nextAlarmClock?.triggerTime ?: return null
    return DateFormat.getTimeFormat(context).format(Date(trigger))
}
