package dev.usecomet.cometos.core.device

import android.content.Context
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Flashlight via CameraManager.setTorchMode (no CAMERA permission needed). */
class TorchController(context: Context) {
    private val manager = context.getSystemService(CameraManager::class.java)

    private val cameraId: String? = runCatching {
        manager.cameraIdList.firstOrNull {
            val c = manager.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    }.getOrNull()

    private val _isOn = MutableStateFlow(false)
    val isOn: StateFlow<Boolean> = _isOn.asStateFlow()
    val isAvailable: Boolean get() = cameraId != null

    private val callback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            if (id == cameraId) _isOn.value = enabled
        }
    }

    fun register() = manager.registerTorchCallback(callback, null)
    fun unregister() = manager.unregisterTorchCallback(callback)

    fun toggle() {
        val id = cameraId ?: return
        try {
            manager.setTorchMode(id, !_isOn.value)
        } catch (_: CameraAccessException) {
            // Camera in use by another app: ignore.
        }
    }
}
