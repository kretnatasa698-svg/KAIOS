package dev.usecomet.cometos

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.usecomet.cometos.core.launcher.DefaultLauncherHelper
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class LauncherScreen { Home, AppLibrary, Settings }

data class LauncherUiState(
    val screen: LauncherScreen = LauncherScreen.Home,
    val isDefaultLauncher: Boolean = false,
    val isLocked: Boolean = true,
)

/** Single source of truth for top-level launcher navigation (unidirectional flow). */
@HiltViewModel
class MainViewModel @Inject constructor(
    private val defaultLauncher: DefaultLauncherHelper,
) : ViewModel() {

    private val _state = MutableStateFlow(
        LauncherUiState(isDefaultLauncher = defaultLauncher.isDefaultLauncher())
    )
    val state: StateFlow<LauncherUiState> = _state.asStateFlow()

    fun refreshDefaultStatus() {
        _state.update { it.copy(isDefaultLauncher = defaultLauncher.isDefaultLauncher()) }
    }

    /** Home pressed while already running: back to the root screen (lock state is kept). */
    fun onHomePressed() = _state.update { it.copy(screen = LauncherScreen.Home) }

    fun navigate(screen: LauncherScreen) = _state.update { it.copy(screen = screen) }

    /** Back never leaves the launcher; it only pops to Home. */
    fun onBack() = _state.update { it.copy(screen = LauncherScreen.Home) }

    fun lock() = _state.update { it.copy(isLocked = true, screen = LauncherScreen.Home) }
    fun unlock() = _state.update { it.copy(isLocked = false) }

    fun createSetDefaultIntent() = defaultLauncher.createSetDefaultIntent()
}
