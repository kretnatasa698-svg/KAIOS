package dev.usecomet.cometos.feature.lock

import android.graphics.Typeface
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontFeatureSettings
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.sp
import dev.usecomet.cometos.R
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

// Swap for a bundled display font (res/font, e.g. a tall condensed face) to match the mockup exactly.
private val ClockFont = FontFamily(Typeface.create("sans-serif-condensed", Typeface.NORMAL))

private const val SQUEEZE = 0.6f // horizontal squeeze that gives the tall, narrow digits

/** Huge minimalist "HHmm" clock. Tabular figures so digits never jitter between minutes. */
@Composable
fun LockClock(time: LocalDateTime, is24h: Boolean, modifier: Modifier = Modifier) {
    val digits = remember(time, is24h) {
        time.format(DateTimeFormatter.ofPattern(if (is24h) "HHmm" else "hhmm"))
    }
    val spoken = remember(time, is24h) {
        time.format(DateTimeFormatter.ofPattern(if (is24h) "HH:mm" else "h:mm a"))
    }
    val description = stringResource(R.string.cd_clock, spoken)

    BoxWithConstraints(modifier.clearAndSetSemantics { contentDescription = description }) {
        // 4 digits are ~2.0em wide before squeezing -> 2.0 * SQUEEZE em after.
        val fontSize = with(LocalDensity.current) { (maxWidth.toPx() / (2f * SQUEEZE)).toSp() }
        Text(
            text = digits,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Clip,
            style = TextStyle(
                fontFamily = ClockFont,
                fontSize = fontSize,
                lineHeight = fontSize,
                letterSpacing = (-2).sp,
                color = Color.White.copy(alpha = 0.58f),
                fontFeatureSettings = FontFeatureSettings("tnum"),
            ),
            modifier = Modifier.layout { measurable, constraints ->
                val placeable = measurable.measure(constraints.copy(maxWidth = Constraints.Infinity))
                layout((placeable.width * SQUEEZE).roundToInt(), placeable.height) {
                    placeable.placeWithLayer(0, 0) {
                        scaleX = SQUEEZE
                        transformOrigin = TransformOrigin(0f, 0.5f)
                    }
                }
            },
        )
    }
}
