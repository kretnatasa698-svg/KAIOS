package dev.usecomet.cometos.core.glass

import android.os.Build
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext

/** True when the user turned animations off (Developer options / accessibility). */
@Composable
fun rememberReducedMotion(): Boolean {
    val context = LocalContext.current
    return remember {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }
}

/**
 * Depth-of-field blur driven by a lambda (read in the layer phase, so animating it does
 * not recompose). RenderEffect needs API 31+; below that this is a no-op and callers rely
 * on alpha/scale to sell the transition.
 */
fun Modifier.depthBlur(radiusPx: () -> Float): Modifier = graphicsLayer {
    val r = radiusPx()
    renderEffect = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && r > 0.5f) {
        BlurEffect(r, r, TileMode.Decal)
    } else {
        null
    }
}
