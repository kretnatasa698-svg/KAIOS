package dev.usecomet.cometos.core.glass

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

/** Sharp + pre-blurred wallpaper. [GlassSurface] samples [blurred] to fake backdrop blur. */
@Immutable
class GlassBackdrop(
    val sharp: ImageBitmap?,
    val blurred: ImageBitmap?,
    val rootSize: IntSize,
)

val LocalGlassBackdrop = compositionLocalOf { GlassBackdrop(null, null, IntSize.Zero) }

/**
 * Root container: draws the wallpaper (or a fallback gradient) and exposes the blurred
 * copy to every GlassSurface below it. Wrap the whole launcher UI exactly once.
 */
@Composable
fun GlassBackdropProvider(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val context = LocalContext.current
    var size by remember { mutableStateOf(IntSize.Zero) }
    val images by produceState<Pair<ImageBitmap, ImageBitmap>?>(null, size) {
        if (size == IntSize.Zero) return@produceState
        value = withContext(Dispatchers.Default) { WallpaperLoader.load(context, size.width, size.height) }
    }
    val backdrop = remember(images, size) { GlassBackdrop(images?.first, images?.second, size) }

    CompositionLocalProvider(
        LocalGlassBackdrop provides backdrop,
        LocalContentColor provides Color.White,
    ) {
        Box(modifier.fillMaxSize().onSizeChanged { size = it }.background(Color(0xFF0B0F14))) {
            backdrop.sharp?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            content()
        }
    }
}

internal object WallpaperLoader {

    /** Returns (sharp, blurred), both already cropped to the screen aspect ratio. */
    fun load(context: Context, width: Int, height: Int): Pair<ImageBitmap, ImageBitmap> {
        val scale = (720f / width).coerceAtMost(1f)
        val tw = max(1, (width * scale).toInt())
        val th = max(1, (height * scale).toInt())
        val sharp = runCatching {
            // Needs READ_EXTERNAL_STORAGE on some API levels; falls back if denied.
            WallpaperManager.getInstance(context).drawable?.let { render(it, tw, th) }
        }.getOrNull() ?: fallback(tw, th)
        val blurred = BitmapBlur.blur(sharp, scaleDown = 6, radius = 7, passes = 3)
        return sharp.asImageBitmap() to blurred.asImageBitmap()
    }

    private fun render(d: Drawable, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val dw = d.intrinsicWidth.coerceAtLeast(1)
        val dh = d.intrinsicHeight.coerceAtLeast(1)
        val s = max(w / dw.toFloat(), h / dh.toFloat()) // center-crop
        c.translate((w - dw * s) / 2f, (h - dh * s) / 2f)
        c.scale(s, s)
        d.setBounds(0, 0, dw, dh)
        d.draw(c)
        return bmp
    }

    private fun fallback(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(0xFF4A515B.toInt(), 0xFF1C2026.toInt(), 0xFF07090B.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP,
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = RadialGradient(
            w * 0.75f, h * 0.2f, w * 0.9f,
            0x553A7BD5, 0x00000000, Shader.TileMode.CLAMP,
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        return bmp
    }
}
