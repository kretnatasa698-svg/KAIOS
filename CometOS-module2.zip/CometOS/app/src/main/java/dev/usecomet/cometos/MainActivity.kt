package dev.usecomet.cometos

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import dagger.hilt.android.AndroidEntryPoint
import dev.usecomet.cometos.core.launcher.DefaultLauncherHelper
import dev.usecomet.cometos.feature.home.LauncherRoot
import dev.usecomet.cometos.ui.theme.CometTheme

// FragmentActivity (a ComponentActivity subclass) is required by androidx.biometric.
@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = viewModel.lock()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ContextCompat.registerReceiver(
            this, screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        setContent {
            CometTheme { LauncherRoot(viewModel) }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshDefaultStatus()
    }

    override fun onDestroy() {
        unregisterReceiver(screenOffReceiver)
        super.onDestroy()
    }

    /** singleTask: a Home press while we are alive is delivered here. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (DefaultLauncherHelper.isHomeIntent(intent)) viewModel.onHomePressed()
    }
}
