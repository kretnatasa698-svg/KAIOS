package dev.usecomet.cometos.core.launcher

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/** Checks and requests the "default home app" role using only public APIs. */
@Singleton
class DefaultLauncherHelper @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val homeIntent: Intent
        get() = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)

    /** True when the system currently resolves Home to this app. */
    fun isDefaultLauncher(): Boolean {
        val resolved = context.packageManager
            .resolveActivity(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolved?.activityInfo?.packageName == context.packageName
    }

    /**
     * Intent that lets the user pick CometOS as Home.
     * API 29+: RoleManager dialog. API 26-28: the Home settings screen.
     */
    fun createSetDefaultIntent(): Intent =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME)
            } else {
                Intent(Settings.ACTION_HOME_SETTINGS)
            }
        } else {
            Intent(Settings.ACTION_HOME_SETTINGS)
        }

    companion object {
        /** True for the intent the system sends when Home is pressed. */
        fun isHomeIntent(intent: Intent?): Boolean =
            intent?.action == Intent.ACTION_MAIN &&
                intent.categories?.contains(Intent.CATEGORY_HOME) == true
    }
}
