package dev.usecomet.cometos.core.glass

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp

/**
 * THE single glass component. Every translucent panel in CometOS goes through it.
 *
 * Layers (bottom to top): blurred wallpaper slice -> tint -> top sheen -> 1dp inner border.
 * The backdrop slice is aligned using the surface's position in the root, so the blur
 * always matches what is really behind it. All brushes are built in drawWithCache,
 * so the draw pass itself does not allocate.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    tint: Color = Color.White,
    tintAlpha: Float = 0.14f,
    borderAlpha: Float = 0.38f,
    blurBackdrop: Boolean = true,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val backdrop = LocalGlassBackdrop.current
    var origin by remember { mutableStateOf(Offset.Zero) } // read only while drawing

    Box(
        modifier = modifier
            .onGloballyPositioned { origin = it.positionInRoot() }
            .clip(shape)
            .drawWithCache {
                val outline = shape.createOutline(size, layoutDirection, this)
                val borderWidth = 2.dp.toPx() // half is clipped away -> 1dp inner border
                val border = Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = borderAlpha),
                        Color.White.copy(alpha = borderAlpha * 0.12f),
                        Color.White.copy(alpha = borderAlpha * 0.5f),
                    ),
                    start = Offset.Zero,
                    end = Offset(size.width, size.height),
                )
                val sheen = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.10f), Color.Transparent),
                    endY = size.height * 0.65f,
                )
                val tintColor = tint.copy(alpha = tintAlpha)
                onDrawBehind {
                    val blurred = backdrop.blurred
                    if (blurBackdrop && blurred != null && backdrop.rootSize != IntSize.Zero) {
                        translate(-origin.x, -origin.y) {
                            drawImage(blurred, dstSize = backdrop.rootSize, filterQuality = FilterQuality.Low)
                        }
                    }
                    drawRect(tintColor)
                    drawRect(sheen)
                    drawOutline(outline, border, style = Stroke(borderWidth))
                }
            }
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier),
        content = content,
    )
}
