package dev.usecomet.cometos

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CometApp : Application()
