package dev.usecomet.cometos.feature.lock

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.usecomet.cometos.core.media.MediaRepository
import javax.inject.Inject

@HiltViewModel
class LockViewModel @Inject constructor(
    private val mediaRepository: MediaRepository,
) : ViewModel() {
    val media = mediaRepository.state

    fun refreshMedia() = mediaRepository.refresh()
    fun togglePlayPause() = mediaRepository.togglePlayPause()
    fun next() = mediaRepository.next()
    fun previous() = mediaRepository.previous()
}
