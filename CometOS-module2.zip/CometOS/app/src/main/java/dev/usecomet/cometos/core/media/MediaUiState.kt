package dev.usecomet.cometos.core.media

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.compose.runtime.Immutable

@Immutable
data class MediaUiState(
    val hasAccess: Boolean = false,
    val title: String? = null,
    val artist: String? = null,
    val art: Bitmap? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0L,
    val positionMs: Long = 0L,
    /** SystemClock.elapsedRealtime() at the moment [positionMs] was reported. */
    val updatedAtElapsed: Long = 0L,
    val speed: Float = 1f,
) {
    val hasTrack: Boolean get() = title != null

    /** Extrapolates the playback position so the UI can tick without polling the session. */
    fun positionNow(nowElapsed: Long = SystemClock.elapsedRealtime()): Long {
        if (!isPlaying) return positionMs
        val advanced = positionMs + ((nowElapsed - updatedAtElapsed) * speed).toLong()
        return advanced.coerceIn(0L, if (durationMs > 0) durationMs else Long.MAX_VALUE)
    }
}
