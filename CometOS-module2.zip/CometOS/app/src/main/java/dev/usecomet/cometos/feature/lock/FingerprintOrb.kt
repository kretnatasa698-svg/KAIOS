package dev.usecomet.cometos.feature.lock

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import dev.usecomet.cometos.R
import dev.usecomet.cometos.core.glass.rememberReducedMotion
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private const val PARTICLES = 24 // fixed pool: nothing is allocated per frame
private const val TAU = (2 * PI).toFloat()

/**
 * Glass fingerprint orb with a pulsing glow and orbiting particles.
 * Three layers: animated particles (redrawn every frame), static glass orb and static
 * ridges (drawn once). With reduced motion the loop never starts.
 */
@Composable
fun FingerprintOrb(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val reduced = rememberReducedMotion()
    var frameNanos by remember { mutableLongStateOf(0L) }
    LaunchedEffect(reduced) {
        if (reduced) return@LaunchedEffect
        while (true) androidx.compose.runtime.withFrameNanos { frameNanos = it }
    }
    // Per particle: start angle, speed, phase.
    val seeds = remember { Random(42).let { r -> FloatArray(PARTICLES * 3) { r.nextFloat() } } }
    val description = stringResource(R.string.cd_fingerprint)

    Box(
        modifier = modifier
            .size(144.dp)
            .semantics { contentDescription = description; role = Role.Button }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
    ) {
        // 1) animated glow + particles
        Canvas(Modifier.fillMaxSize()) {
            val t = frameNanos / 1_000_000_000f
            val c = center
            val base = size.minDimension * 0.30f
            val pulse = if (reduced) 0.5f else 0.5f + 0.5f * sin(t * 2f)
            drawCircle(Color(0xFF9CC8FF).copy(alpha = 0.10f + 0.12f * pulse), base * (1.5f + 0.25f * pulse), c)
            val dot = 1.6.dp.toPx()
            for (i in 0 until PARTICLES) {
                val a0 = seeds[i * 3] * TAU
                val speed = 0.15f + seeds[i * 3 + 1] * 0.35f
                val phase = seeds[i * 3 + 2]
                val life = if (reduced) phase else (t * speed + phase) % 1f
                val dir = if (i % 2 == 0) 1f else -1f
                val angle = a0 + (if (reduced) 0f else t * 0.35f * dir)
                val radius = base * (1.08f + 0.95f * life)
                drawCircle(
                    Color.White.copy(alpha = (1f - life) * 0.75f),
                    dot * (1.3f - life * 0.7f),
                    Offset(c.x + cos(angle) * radius, c.y + sin(angle) * radius),
                )
            }
        }
        // 2) static glass orb
        Box(
            Modifier.align(androidx.compose.ui.Alignment.Center).size(86.dp).drawWithCache {
                val fill = Brush.radialGradient(
                    listOf(Color.White.copy(0.30f), Color.White.copy(0.08f)),
                    center = Offset(size.width * 0.35f, size.height * 0.3f),
                    radius = size.width,
                )
                val rim = Brush.linearGradient(
                    listOf(Color.White.copy(0.7f), Color.White.copy(0.08f), Color.White.copy(0.4f)),
                    start = Offset.Zero, end = Offset(size.width, size.height),
                )
                onDrawBehind {
                    drawCircle(fill)
                    drawCircle(rim, style = Stroke(1.5.dp.toPx()))
                }
            },
        )
        // 3) static fingerprint ridges
        Canvas(Modifier.align(androidx.compose.ui.Alignment.Center).size(86.dp)) {
            val stroke = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round)
            val fractions = floatArrayOf(0.10f, 0.18f, 0.26f, 0.34f)
            for (i in fractions.indices) {
                val r = size.minDimension * fractions[i]
                drawArc(
                    Color.White.copy(0.9f),
                    startAngle = 200f + i * 14f,
                    sweepAngle = 250f - i * 22f,
                    useCenter = false,
                    topLeft = Offset(center.x - r, center.y - r),
                    size = Size(r * 2, r * 2),
                    style = stroke,
                )
            }
        }
    }
}
