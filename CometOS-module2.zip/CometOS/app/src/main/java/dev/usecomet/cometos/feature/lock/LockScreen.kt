package dev.usecomet.cometos.feature.lock

import android.content.ActivityNotFoundException
import android.content.Intent
import android.provider.MediaStore
import android.provider.Settings
import android.text.format.DateFormat
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FlashlightOff
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.usecomet.cometos.R
import dev.usecomet.cometos.core.device.TorchController
import dev.usecomet.cometos.core.device.batteryPercentFlow
import dev.usecomet.cometos.core.device.nextAlarmLabel
import dev.usecomet.cometos.core.glass.GlassSurface
import dev.usecomet.cometos.core.glass.depthBlur
import dev.usecomet.cometos.core.glass.rememberReducedMotion
import dev.usecomet.cometos.core.security.BiometricUnlock
import dev.usecomet.cometos.core.util.findActivity
import dev.usecomet.cometos.core.util.minuteTicks
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.launch

/**
 * In-launcher lock overlay (the real keyguard cannot be replaced by a launcher).
 *
 * [progress] is hoisted: 0 = locked, 1 = fully unlocked. The same value drives the lock
 * layer (blur-out, scale-up, fade) and the Home layer (blur-in) so the two stay in sync.
 */
@Composable
fun LockScreen(
    progress: Animatable<Float, AnimationVector1D>,
    onUnlocked: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: LockViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current
    val reducedMotion = rememberReducedMotion()
    val media by viewModel.media.collectAsStateWithLifecycle()

    LifecycleResumeEffect(Unit) {
        viewModel.refreshMedia()
        onPauseOrDispose { }
    }

    val now by produceState(LocalDateTime.now()) { minuteTicks().collect { value = it } }
    val battery by remember { batteryPercentFlow(context) }.collectAsStateWithLifecycle(initialValue = null)
    val alarm = remember(now) { nextAlarmLabel(context) }
    val is24h = remember { DateFormat.is24HourFormat(context) }
    val dateText = remember(now) {
        now.format(DateTimeFormatter.ofPattern("d MMM EEE", Locale.getDefault()))
    }

    val torch = remember { TorchController(context) }
    val torchOn by torch.isOn.collectAsStateWithLifecycle()
    DisposableEffect(torch) {
        torch.register()
        onDispose { torch.unregister() }
    }

    suspend fun finishUnlock() {
        if (reducedMotion) progress.snapTo(1f)
        else progress.animateTo(1f, spring(Spring.DampingRatioNoBouncy, Spring.StiffnessMediumLow))
        onUnlocked()
    }

    BoxWithConstraints(modifier.fillMaxSize()) {
        val thresholdPx = with(LocalDensity.current) { maxHeight.toPx() * 0.45f }
        val blurMaxPx = with(LocalDensity.current) { 28.dp.toPx() }

        val dragState = rememberDraggableState { delta ->
            scope.launch { progress.snapTo((progress.value - delta / thresholdPx).coerceIn(0f, 1f)) }
        }

        Column(
            Modifier
                .fillMaxSize()
                .draggable(
                    state = dragState,
                    orientation = Orientation.Vertical,
                    onDragStopped = { velocity ->
                        scope.launch {
                            if (progress.value > 0.4f || velocity < -1800f) {
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                finishUnlock()
                            } else if (reducedMotion) {
                                progress.snapTo(0f)
                            } else {
                                progress.animateTo(0f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow))
                            }
                        }
                    },
                )
                .graphicsLayer {
                    val p = progress.value
                    alpha = (1f - p * 1.15f).coerceIn(0f, 1f)
                    translationY = -p * size.height * 0.16f
                    val s = 1f + 0.08f * p
                    scaleX = s
                    scaleY = s
                }
                .depthBlur { progress.value * blurMaxPx }
                .background(Brush.verticalGradient(listOf(Color.Black.copy(0.30f), Color.Black.copy(0.12f), Color.Black.copy(0.45f))))
                .systemBarsPadding()
                .padding(horizontal = 24.dp),
        ) {
            Spacer(Modifier.height(20.dp))
            Text(dateText, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                LockClock(now, is24h, Modifier.weight(1f))
                Spacer(Modifier.width(12.dp))
                LockSideWidgets(battery, alarm)
            }
            Spacer(Modifier.weight(1f))

            FingerprintOrb(
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    val activity = context.findActivity() as? FragmentActivity
                    val unlock: () -> Unit = { scope.launch { finishUnlock() } }
                    if (activity == null) unlock()
                    else BiometricUnlock.authenticate(
                        activity,
                        context.getString(R.string.biometric_title),
                        context.getString(R.string.biometric_subtitle),
                        unlock,
                    )
                },
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )
            Spacer(Modifier.height(20.dp))

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                RoundGlassButton(
                    onClick = torch::toggle,
                    description = stringResource(if (torchOn) R.string.cd_torch_on else R.string.cd_torch_off),
                ) {
                    Icon(if (torchOn) Icons.Rounded.FlashlightOn else Icons.Rounded.FlashlightOff, contentDescription = null)
                }
                MusicCard(
                    state = media,
                    onOpenAccess = {
                        context.startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    },
                    onPrevious = viewModel::previous,
                    onPlayPause = viewModel::togglePlayPause,
                    onNext = viewModel::next,
                    modifier = Modifier.weight(1f),
                )
                RoundGlassButton(
                    onClick = {
                        try {
                            context.startActivity(
                                Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        } catch (_: ActivityNotFoundException) {
                        }
                    },
                    description = stringResource(R.string.cd_camera),
                ) { Icon(Icons.Rounded.PhotoCamera, contentDescription = null) }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                stringResource(R.string.lock_hint),
                modifier = Modifier.fillMaxWidth().alpha(0.85f),
                textAlign = TextAlign.Center,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun RoundGlassButton(
    onClick: () -> Unit,
    description: String,
    icon: @Composable () -> Unit,
) {
    GlassSurface(
        modifier = Modifier.size(64.dp).androidSemanticsDescription(description),
        shape = CircleShape,
        tintAlpha = 0.16f,
        onClick = onClick,
    ) {
        androidx.compose.foundation.layout.Box(Modifier.matchParentSize(), contentAlignment = Alignment.Center) { icon() }
    }
}

private fun Modifier.androidSemanticsDescription(description: String): Modifier =
    this.then(Modifier.semantics { contentDescription = description })
