package dev.usecomet.cometos.feature.lock

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.DirectionsWalk
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.usecomet.cometos.R
import dev.usecomet.cometos.core.glass.GlassSurface

/** Right-hand column of glass tiles. Battery and alarm are live; steps/temperature are placeholders. */
@Composable
fun LockSideWidgets(batteryPercent: Int?, nextAlarm: String?, modifier: Modifier = Modifier) {
    val unknown = stringResource(R.string.value_unknown)
    val batteryText = batteryPercent?.let { "$it%" } ?: unknown
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SideTile(Icons.Rounded.BatteryChargingFull, batteryText, stringResource(R.string.cd_battery, batteryText))
        SideTile(Icons.Rounded.DirectionsWalk, unknown, stringResource(R.string.cd_steps))
        SideTile(Icons.Rounded.Thermostat, unknown, stringResource(R.string.cd_temperature))
        SideTile(Icons.Rounded.Alarm, nextAlarm ?: unknown, stringResource(R.string.cd_alarm))
    }
}

@Composable
private fun SideTile(icon: ImageVector, value: String, description: String) {
    GlassSurface(
        modifier = Modifier.size(72.dp).clearAndSetSemantics { contentDescription = "$description $value" },
        shape = RoundedCornerShape(24.dp),
        tintAlpha = 0.12f,
    ) {
        Column(
            modifier = Modifier.matchParentSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(24.dp))
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}
