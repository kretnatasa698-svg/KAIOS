package dev.usecomet.cometos

import dev.usecomet.cometos.core.media.MediaUiState
import org.junit.Assert.assertEquals
import org.junit.Test

class MediaUiStateTest {
    @Test
    fun pausedTrackKeepsReportedPosition() {
        val s = MediaUiState(isPlaying = false, positionMs = 30_000, durationMs = 200_000, updatedAtElapsed = 1_000)
        assertEquals(30_000L, s.positionNow(nowElapsed = 9_000))
    }

    @Test
    fun playingTrackAdvancesWithSpeed() {
        val s = MediaUiState(isPlaying = true, positionMs = 10_000, durationMs = 200_000, updatedAtElapsed = 1_000, speed = 2f)
        assertEquals(14_000L, s.positionNow(nowElapsed = 3_000))
    }

    @Test
    fun positionNeverExceedsDuration() {
        val s = MediaUiState(isPlaying = true, positionMs = 199_000, durationMs = 200_000, updatedAtElapsed = 0)
        assertEquals(200_000L, s.positionNow(nowElapsed = 60_000))
    }
}
